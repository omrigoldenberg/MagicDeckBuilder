# Functionality and Motivation
Magic: the Gathering is a popular trading card game that we both play. Competitive tournaments are held for it, where cash is on the line. Usually, the player with the better deck that wins. As such, tools that help in the creation of decklists are extremely useful, and of commercial interest, such as with TappedOut's subscription and MTGGoldfish's superbrew service.
As such, we endeavor to make our own deck builder, with unique, useful features that are not present in current offerings, such as a crowdsourced sideboard guide. That tool would use user data to determine which cards are best to put in or take out when you know your opponent is playing a certain deck. Such decisions are often extremely for novice players, who may not fully understand their own deck, nor their opponent's.
In addition, professional Magic: the Gathering players sell guides that try to do this. Our solution would dynamically generate such content. While this is ambitious, we believe that it will still be possible through the use of existing, public Magic: the Gathering APIs such as Scryfall to source data about the cards themselves, as well as the use of database technology to track our user's trends for what they would sideboard in or out in a given matchup.
On the site, users would create decklists by typing in names and quantities of cards. Our tool would analyze the decklist and confirm that whatever type of tournament the user wants to play that deck in would allow such a deck and confirm it is a valid decklist. Then, after a user submits a deck, they would come back and submit data about the matches they've played with it, what they sided in, what they sided out, and their win record. Other users could also submit similar data for other user's decklists if they mark them as public. Based on the average of these data, the site would generate a list of cards to sideboard in or out for such a matchup.

# Meeting Minimum Requirements
* HTML and CSS: we will write our webpages in HTML and use CSS for styling
* Python-Flask: our backend will be made in Flask
* WTForms: our decklist submissions, as well as tournament results, will be reported through a form.
* Flask-SQLAlchemy: our deck and tournament result database will be accessed through Flask-SQLAlchemy
* Flask-Login: user accounts for storing decklists and tournament results will be accessed through Flask-Login.
* Create Account and Hash Passwords: see above
* Accept user data and store it: store decklists, tournament records
* Provide that data in a meaningful way: show decklists in visual form, show submitted tournament records
* Serve a reasonable purpose: as explained in the functionality and motivation, such a tool would be useful to both us as well as the greater Magic: the Gathering community.

# Going Beyond Minimum
* Use of external APIs: we plan to use the Scryfall API (see [here](https://scryfall.com/docs/api)) to help implement some of our needed features. Scryfall is actually implemented with a REST-like API.
* OAuth integration: we plan to add OAuth login options
* Live Multi-User Interaction: we plan to allow multiple users to edit a sideboard guide at once.
* User Data Combination: we plan to meaningfully manipulate user-uploaded data.

# Who Plans to Work On What
Omri will do the front end (HTML, CSS, user-end Javascript) for most pages and login pages on both front and back end.
Jon will do the deckbuilder in Flask.
We will both work on the sideboard guide portion together.

# Github Repository Link
The repository available [here](https://github.com/JonWStudent/twoheadedgiant/). In line with College rules, it is a private repository. If you need access, please [email me](mailto:jwaxman2@u.rochester.edu) know your GitHub username and I can add you.
