# To Run
Use the command `python -m flask run` after having set your `FLASK_APP` environment variable to `app/__init__.py` [using `set` or `export`, depending on your OS]
